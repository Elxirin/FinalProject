import { Injectable } from '@angular/core';
import { Observable } from '../../../node_modules/rxjs';
import { HttpClient } from '../../../node_modules/@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ImageService {

  images: any[];

  constructor(private http: HttpClient) {
    this.populateImages().subscribe(data => {
      this.images = data;
      console.log(data);
    }, error => console.log(error));
  }

  populateImages(): Observable<any[]> {
    return this.http.get<any[]>("http://localhost:6500/productimages/1001");
  }


  getImages(): any[] {
    return this.images;
  }
}
