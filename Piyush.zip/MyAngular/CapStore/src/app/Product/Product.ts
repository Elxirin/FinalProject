export interface Product {
    productId: number;
    productName: string;
    categoryId: number;
    price: number;
   
}