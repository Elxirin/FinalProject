import { Component, OnInit } from '@angular/core';
import { Product } from './Product';
import { ProductService } from './product.service';
import { ImageService } from './image.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  bntStyle: string;
  products: Product[];
  images: any[];
  image1: string;
  image2: string;
  prod1: Product;
  

  constructor(private prodService: ProductService, private imgService: ImageService) {
    prodService.populateProduct().subscribe(data => this.products = data, error => console.log(error));
    imgService.populateImages().subscribe(data => this.images = data, error => console.log(error));
  }

  ngOnInit() {
    this.products = this.prodService.getProduct();
    this.images = this.imgService.getImages();
    setTimeout(() => {
      this.image1 = this.images[0].url;
      this.image2 = this.images[1].url;
      this.prod1 = this.products[0];
      console.log(this.image1+" "+this.image2);
    }, 150)

  }


  addToWishlist() {
    console.log("here");
    this.bntStyle = 'btn-change';
    console.log("Products:" + this.products[0].productName);
    console.log("Image:" + this.images);

  }
}
