import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HomeComponent } from './Home/home.component';

import {MatToolbarModule} from '@angular/material/toolbar';
import { MatMenuModule, MatButtonModule, MatIconModule, MatCardModule, MatBadgeModule,MatExpansionModule,MatRadioModule } from '@angular/material';
import { NavComponent } from './Home/Nav/nav.component';
import { ShopFilterComponent } from './Home/ShopFilter/shop-filter.component';
import { SimilarProductComponent } from './Similar/SimilarProd/similar-product.component';
import { SimilarProductContainerComponent } from './Similar/SimilarProdCont/similar-product-container.component';
import { PaymentModeComponent } from './Payement/payment-mode.component';
import { WishlistComponent } from './WishList/wishlist.component';
import { ProductComponent } from './Product/product.component';
import { HttpClientModule } from '../../node_modules/@angular/common/http';




@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavComponent,
    ShopFilterComponent,
    SimilarProductComponent,
    SimilarProductContainerComponent,
    PaymentModeComponent,
    WishlistComponent,
    ProductComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatCardModule,
    MatBadgeModule,
    MatExpansionModule,
    MatRadioModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
