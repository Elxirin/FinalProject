import { Component, OnInit } from '@angular/core';
import { Product } from '../../Product/Product';
import { SimilarProductService } from './similar-product.service';

@Component({
  selector: 'app-similar-product',
  templateUrl: './similar-product.component.html',
  styleUrls: ['./similar-product.component.css']
})
export class SimilarProductComponent implements OnInit {

  products: Product[];

  constructor(private similarProdService: SimilarProductService) {
    similarProdService.populateProduct().subscribe(data=>this.products=data, error=>console.log(error));
   }

   url="http://localhost:5000/downloadFile/a8c721e6-d5c4-493c-a7a9-ff53f7bddf54";
  ngOnInit() {
     this.products = this.similarProdService.getProduct();
  }

}
