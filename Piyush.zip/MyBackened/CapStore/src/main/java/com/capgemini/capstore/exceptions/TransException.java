package com.capgemini.capstore.exceptions;

public class TransException extends Exception {

	public TransException() {
		super();
	}
	
	public TransException(String msg) {
		super(msg);
	}
}
