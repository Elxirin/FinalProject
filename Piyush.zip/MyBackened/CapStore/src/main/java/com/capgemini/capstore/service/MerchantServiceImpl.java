package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.dao.MerchantRepository;
import com.capgemini.capstore.exceptions.MerchantException;

public class MerchantServiceImpl implements MerchantService {

	@Autowired
	private MerchantRepository merchantRepo;
	
	@Override
	public List<Merchant> getAllTransactions() throws MerchantException {
		try {
			return merchantRepo.findAll();
		} catch (Exception e) {
			throw new MerchantException(e.getMessage());
					}
	}

	
	@Override
    public Merchant getMerchantById(int id) throws MerchantException {
       
        if(!merchantRepo.existsById(id)) {
            throw new MerchantException("Merchant with id "+id+" does not exists");
        }else {
            return merchantRepo.findById(id).get();
        }
    }
	
	@Override
	public List<Merchant> onPlaceAddRevenue(int id,double price) throws MerchantException {
		System.out.println(id+"    "+price);
		if (!merchantRepo.existsById(id)) {
			throw new MerchantException("Merchant with id " + id+ "does not exists");
		}
		Merchant m=getMerchantById(id);
		m.setRevenue(m.getRevenue()+price);
		merchantRepo.save(m);
		return getAllTransactions();
	}
	
}
