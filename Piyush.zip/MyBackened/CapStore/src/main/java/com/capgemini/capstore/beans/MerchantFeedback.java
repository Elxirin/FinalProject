package com.capgemini.capstore.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class MerchantFeedback {
	@Id
	@SequenceGenerator(name = "merchfeed_id", sequenceName = "merchfeed_id", initialValue = 40000, allocationSize = 1)
	@GeneratedValue(generator = "merchfeed_id")
	private int merchantFeedbackId;
	private int merchantId;
	private String feedback;
	private int rating;

	public MerchantFeedback() {
		super();
	}

	public MerchantFeedback(int merchantFeedbackId, int merchantId, String feedback, int rating) {
		super();
		this.merchantFeedbackId = merchantFeedbackId;
		this.merchantId = merchantId;
		this.feedback = feedback;
		this.rating = rating;
	}

	public int getMerchantFeedbackId() {
		return merchantFeedbackId;
	}

	public void setMerchantFeedbackId(int merchantFeedbackId) {
		this.merchantFeedbackId = merchantFeedbackId;
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	@Override
	public String toString() {
		return "MerchantFeedback [merchantFeedbackId=" + merchantFeedbackId + ", merchantId=" + merchantId
				+ ", feedback=" + feedback + ", rating=" + rating + "]";
	}

}
