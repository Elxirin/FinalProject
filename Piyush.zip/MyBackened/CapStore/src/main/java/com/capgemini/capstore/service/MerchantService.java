package com.capgemini.capstore.service;

import java.util.List;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.exceptions.MerchantException;

public interface MerchantService {
	public List<Merchant> onPlaceAddRevenue(int id, double price) throws MerchantException;

	public List<Merchant> getAllTransactions() throws MerchantException;

	Merchant getMerchantById(int id) throws MerchantException;
}
