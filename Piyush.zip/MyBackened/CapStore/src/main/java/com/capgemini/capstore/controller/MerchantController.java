package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.capstore.beans.Merchant;

import com.capgemini.capstore.exceptions.MerchantException;

import com.capgemini.capstore.service.MerchantService;


@RestController
@CrossOrigin("http://localhost:4200")
public class MerchantController {
	
	@Autowired
	private MerchantService merchantService;
	
	
	@GetMapping("/merchant/{id}/{price}")
	public List<Merchant> onPlaceAddRevenue(@PathVariable int id, @PathVariable double price) throws MerchantException{
		System.out.println(id+"    "+price);
		return merchantService.onPlaceAddRevenue(id, price);
	}
	
	@GetMapping("/merchant")
	public List<Merchant> getAllTransactions() throws MerchantException{
		return merchantService.getAllTransactions();
	}
	

}
