package com.capgemini.capstore.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Transaction {

	@Id
	@SequenceGenerator(name = "trans_id", sequenceName = "trans_id", initialValue = 90000, allocationSize = 1)
	@GeneratedValue(generator = "trans_id")
	private int transactionId;
	// Net Banking, card or cash
	private String transMode;
	private double amount;
	// Refund or Payment
	private String transactionType;

	public Transaction() {
		super();
	}

	public Transaction(int transactionId, String transMode, double amount, String transactionType) {
		super();
		this.transactionId = transactionId;
		this.transMode = transMode;
		this.amount = amount;
		this.transactionType = transactionType;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransMode() {
		return transMode;
	}

	public void setTransMode(String transMode) {
		this.transMode = transMode;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transMode=" + transMode + ", amount=" + amount
				+ ", transactionType=" + transactionType + "]";
	}

}
